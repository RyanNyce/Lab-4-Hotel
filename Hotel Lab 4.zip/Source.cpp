#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>


using namespace std;
void wait();

int main()
{
	cout << "<Ryan Nyce> -- Lab <4>" << endl << endl;

	//declared variables 
	double roomRate, taxRate, discountRate, salesTax, totalRoomCost;
	int roomsBooked, days;
	ifstream in;
	ofstream out;

	in.open("input.dat");
	in >> roomRate >> taxRate;
	// prompts for user to input information
	cout << "Enter the number of rooms booked: ";
	cin >> roomsBooked;
	cout << "Enter the number of days the rooms are booked: ";
	cin >> days;

	if (roomsBooked < 10)        //10% discount
	{
		discountRate = 0.0;
	}
	else if (roomsBooked < 20)   //20% discount
		discountRate = 0.1;
	else if (roomsBooked < 30)   //30% discount
		discountRate = 0.2;
	else
		discountRate = 0.3;

	if (days >= 3)
		discountRate += 0.05;


	totalRoomCost = 100 * days * roomsBooked;
	salesTax = totalRoomCost * (1 - discountRate) * taxRate;

	out.open("output.dat");
	out << fixed << showpoint << setprecision(2);
	out << setw(30) << right << "Cost of renting one room:\t" << setw(10) << right << 100.00 << endl;
	out << setw(30) << right << "Discount rate per room (%):\t" << setw(10) << right << discountRate * 100 << endl;
	out << setw(30) << right << "Number of rooms booked:\t" << setw(10) << right << (double)roomsBooked << endl;
	out << setw(30) << right << "Number of days booked:\t" << setw(10) << right << (double)days << endl;
	out << setw(30) << right << "Total cost of the rooms ($):\t" << setw(10) << right << totalRoomCost << endl;
	out << setw(30) << right << "Sales tax ($):\t" << setw(10) << right << salesTax << endl;
	out << setw(30) << right << "Total billing amount ($):\t" << setw(10) << right << (totalRoomCost + salesTax);
	out.close();

	wait();
	return 0;

}

void wait()
{

	if (cin.rdbuf()->in_avail() > 0)
	{

		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(), '\n');

	}


}